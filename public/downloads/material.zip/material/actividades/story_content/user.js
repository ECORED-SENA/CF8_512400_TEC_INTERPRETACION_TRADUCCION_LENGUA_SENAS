function ExecuteScript(strId)
{
  switch (strId)
  {
      case "63Mn29P1UQv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

