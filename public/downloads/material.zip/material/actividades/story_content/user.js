function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6KMxPbKrxH8":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

